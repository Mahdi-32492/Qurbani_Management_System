from flask import Flask, render_template, request, redirect, url_for, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'CHANGE_ME'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///qurbani.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ---------------- AUTH ----------------
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if 'user_id' not in session:
            return redirect('/login')
        return f(*args, **kwargs)
    return wrapper

# ---------------- MODELS ----------------
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120))
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)

class Animal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(50))
    shares = db.Column(db.Integer)
    price = db.Column(db.Float)

class Share(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer)
    animal_id = db.Column(db.Integer)
    qty = db.Column(db.Integer)
    total = db.Column(db.Float)

# ---------------- ROUTES ----------------
@app.route('/')
@login_required
def dashboard():
    return render_template("dashboard.html",
        customers=Customer.query.count(),
        animals=Animal.query.count(),
        shares=Share.query.count()
    )

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and check_password_hash(user.password, request.form['password']):
            session['user_id'] = user.id
            return redirect('/')
    return render_template("login.html")

@app.route('/customers', methods=['GET','POST'])
@login_required
def customers():
    if request.method == 'POST':
        db.session.add(Customer(
            name=request.form['name'],
            phone=request.form['phone'],
            address=request.form['address']
        ))
        db.session.commit()
    return render_template("customers.html", customers=Customer.query.all())

@app.route('/animals', methods=['GET','POST'])
@login_required
def animals():
    if request.method == 'POST':
        db.session.add(Animal(
            type=request.form['type'],
            shares=request.form['shares'],
            price=request.form['price']
        ))
        db.session.commit()
    return render_template("animals.html", animals=Animal.query.all())

@app.route('/shares', methods=['GET','POST'])
@login_required
def shares():
    if request.method == 'POST':
        qty = int(request.form['qty'])
        price = float(request.form['price'])
        db.session.add(Share(
            customer_id=1,
            animal_id=1,
            qty=qty,
            total=qty*price
        ))
        db.session.commit()
    return render_template("shares.html", shares=Share.query.all())

if __name__ == "__main__":
    app.run(debug=True)